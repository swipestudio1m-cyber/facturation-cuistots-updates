/* Appli mobile — logique. Utilise window.fflate, window.FactuCore.
   Les appels réseau passent par fetch() ; dans l'APK, CapacitorHttp les route
   en natif → pas de blocage CORS, comme le serveur du PC. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };

  // Version du bundle web — les mises à jour OTA comparent ce numéro à version.json
  var APP_VERSION = '1.2.0';
  var UPDATE_BASE = 'https://raw.githubusercontent.com/swipestudio1m-cyber/facturation-cuistots-updates/main';

  var DEFAULTS = { url: '', db: '', login: '', key: '' };
  var STATE = { months: [], sel: null, uid: null };

  // ---------- réglages (stockés sur le téléphone) ----------
  function getSettings() {
    try { return JSON.parse(localStorage.getItem('odoo') || 'null') || DEFAULTS; } catch (e) { return DEFAULTS; }
  }
  function hasSettings() { var s = getSettings(); return s && s.url && s.db && s.login && s.key; }
  function fillSettings() {
    var s = getSettings();
    $('s_url').value = s.url || ''; $('s_db').value = s.db || ''; $('s_login').value = s.login || ''; $('s_key').value = s.key || '';
    $('app_ver').textContent = APP_VERSION;
  }
  window.saveSettings = function () {
    var s = { url: $('s_url').value.trim().replace(/\/+$/, ''), db: $('s_db').value.trim(), login: $('s_login').value.trim(), key: $('s_key').value.trim() };
    if (!s.url || !s.db || !s.login || !s.key) { $('s_msg').textContent = '⚠️ Remplis tous les champs.'; return; }
    localStorage.setItem('odoo', JSON.stringify(s)); STATE.uid = null;
    $('s_msg').textContent = '✅ Enregistré.'; setTimeout(reset, 500);
  };

  // ---------- Odoo ----------
  function rpc(service, method, args) {
    var s = getSettings();
    return fetch(s.url + '/jsonrpc', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', method: 'call', params: { service: service, method: method, args: args }, id: 1 }) })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j.error) throw new Error((j.error.data && j.error.data.message) || j.error.message || 'Erreur Odoo'); return j.result; });
  }
  function auth() {
    var s = getSettings();
    if (STATE.uid) return Promise.resolve(STATE.uid);
    return rpc('common', 'authenticate', [s.db, s.login, s.key, {}]).then(function (uid) {
      if (!uid) throw new Error('Connexion refusée (identifiant ou clé API incorrects).'); STATE.uid = uid; return uid;
    });
  }
  function kw(model, method, args, kwargs) {
    var s = getSettings();
    return auth().then(function (uid) { return rpc('object', 'execute_kw', [s.db, uid, s.key, model, method, args, kwargs || {}]); });
  }
  window.testOdoo = function () {
    $('s_msg').textContent = 'Test en cours…'; STATE.uid = null;
    auth().then(function () { return kw('res.users', 'read', [[STATE.uid], ['name']]); })
      .then(function (u) { $('s_msg').textContent = '✅ Connecté : ' + u[0].name; })
      .catch(function (e) { $('s_msg').textContent = '❌ ' + e.message; });
  };

  // Factures existantes par mois (id, état, envoyée ou non)
  function existingByMonth() {
    var domain = [[['partner_id', '=', FactuCore.CLIENT_ID], ['move_type', '=', 'out_invoice']]];
    var base = ['id', 'name', 'state', 'invoice_date', 'amount_total', 'invoice_line_ids'];
    function q(fields) { return kw('account.move', 'search_read', domain, { fields: fields }); }
    return q(base.concat(['is_move_sent'])).catch(function () { return q(base); })
      .then(function (invs) {
        var map = {};
        invs.forEach(function (i) {
          if (!i.invoice_date) return;
          var k = i.invoice_date.slice(0, 7);
          (map[k] = map[k] || []).push({
            id: i.id, name: (i.name && i.name !== '/') ? i.name : '(brouillon)',
            state: i.state, amount: i.amount_total, nlines: (i.invoice_line_ids || []).length,
            sent: !!i.is_move_sent,
          });
        });
        return map;
      }).catch(function () { return {}; });
  }

  function lineCommands(mo) {
    var cmds = mo.prestationLines.map(function (l) { return [0, 0, { product_id: l.product_id, name: l.name, quantity: l.quantity, price_unit: l.price_unit, tax_ids: [[6, 0, l.tax]], account_id: FactuCore.ACC_PREST }]; });
    if (mo.meal) cmds.push([0, 0, { product_id: mo.meal.product_id, name: mo.meal.name, quantity: mo.meal.quantity, price_unit: mo.meal.price_unit, tax_ids: [[6, 0, []]], account_id: FactuCore.ACC_MEAL }]);
    return cmds;
  }
  function createDraft(mo) {
    return kw('account.move', 'create', [{ move_type: 'out_invoice', partner_id: FactuCore.CLIENT_ID, invoice_date: mo.invoiceDate, invoice_payment_term_id: FactuCore.PAYMENT_TERM_ID, invoice_line_ids: lineCommands(mo) }])
      .then(function (id) {
        return kw('account.move', 'write', [[id], { name: mo.invoiceName }]).catch(function () {}).then(function () {
          return kw('account.move', 'read', [[id], ['name', 'amount_total']]).then(function (b) {
            return { id: id, name: b[0].name, amount_total: b[0].amount_total, url: getSettings().url + '/odoo/action-account.move/' + id };
          });
        });
      });
  }
  // Remplace toutes les lignes du brouillon existant par celles du planning
  function updateDraft(mo, draftId) {
    var cmds = [[5, 0, 0]].concat(lineCommands(mo));
    return kw('account.move', 'write', [[draftId], { invoice_date: mo.invoiceDate, invoice_line_ids: cmds }])
      .then(function () { return kw('account.move', 'read', [[draftId], ['name', 'amount_total', 'invoice_line_ids']]); })
      .then(function (b) {
        return { id: draftId, name: b[0].name, amount_total: b[0].amount_total, nlines: (b[0].invoice_line_ids || []).length, url: getSettings().url + '/odoo/action-account.move/' + draftId };
      });
  }

  // Comptabiliser une facture (action_post) — validé par prototype le 14/07/2026
  function postInvoice(id) { return kw('account.move', 'action_post', [[id]]); }
  // Envoyer par email via l'assistant d'Odoo (account.move.send.wizard)
  function sendInvoice(id) {
    var ctx = { active_model: 'account.move', active_ids: [id] };
    return kw('account.move.send.wizard', 'create', [{}], { context: ctx })
      .then(function (wid) { return kw('account.move.send.wizard', 'action_send_and_print', [[wid]], { context: ctx }); });
  }
  function getClientEmail() {
    if (STATE.clientEmail) return Promise.resolve(STATE.clientEmail);
    return kw('res.partner', 'read', [[FactuCore.CLIENT_ID], ['email']])
      .then(function (r) { STATE.clientEmail = r[0].email || '(email client non renseigné dans Odoo)'; return STATE.clientEmail; });
  }
  function pickByName(arr, name) {
    var t = null;
    arr.forEach(function (x) { if (x.name === name) t = x; });
    if (!t && arr.length) t = arr.reduce(function (a, b) { return (b.id > a.id ? b : a); });
    return t;
  }

  // ---------- mises à jour automatiques (OTA) ----------
  function isNewer(a, b) {
    var pa = String(a).split('.'), pb = String(b).split('.');
    for (var i = 0; i < 3; i++) { var x = +pa[i] || 0, y = +pb[i] || 0; if (x > y) return true; if (x < y) return false; }
    return false;
  }
  function toast(txt) {
    var t = document.createElement('div');
    t.textContent = txt;
    t.style.cssText = 'position:fixed;left:14px;right:14px;bottom:18px;background:var(--panel2);border:1px solid var(--accent);color:var(--txt);padding:13px 16px;border-radius:12px;z-index:99;text-align:center;font-size:14px';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 6000);
    return t;
  }
  function updaterPlugin() {
    var C = window.Capacitor;
    return (C && C.Plugins && C.Plugins.CapacitorUpdater) || null;
  }
  function checkUpdate(manual) {
    var CU = updaterPlugin();
    if (!CU) { if (manual) $('s_msg').textContent = 'Mises à jour indisponibles (mode navigateur).'; return; }
    if (manual) $('s_msg').textContent = 'Recherche de mise à jour…';
    fetch(UPDATE_BASE + '/version.json?t=' + Date.now())
      .then(function (r) { return r.json(); })
      .then(function (info) {
        if (!info || !info.version || !isNewer(info.version, APP_VERSION)) {
          if (manual) $('s_msg').textContent = '✅ Application à jour (v' + APP_VERSION + ').';
          return;
        }
        toast('⬇️ Mise à jour v' + info.version + ' — installation…');
        if (manual) $('s_msg').textContent = '⬇️ Téléchargement de la v' + info.version + '…';
        return CU.download({ url: UPDATE_BASE + '/www.zip', version: info.version })
          .then(function (b) { return CU.set({ id: b.id }); });   // l'appli redémarre toute seule
      })
      .catch(function (e) { if (manual) $('s_msg').textContent = '❌ Vérification impossible (' + (e.message || 'réseau') + ').'; });
  }
  window.checkUpdateManual = function () { checkUpdate(true); };

  // ---------- URSSAF (estimation des cotisations) ----------
  var MOIS_FR = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function urssafSettings() {
    try { return JSON.parse(localStorage.getItem('urssaf') || 'null') || { rate: 21.2, period: 'M' }; } catch (e) { return { rate: 21.2, period: 'M' }; }
  }
  window.saveUrssafSettings = function () {
    var s = { rate: parseFloat(String($('u_rate').value).replace(',', '.')) || 21.2, period: $('u_period').value };
    localStorage.setItem('urssaf', JSON.stringify(s));
    renderUrssaf();
  };
  function periodKey(dateStr, mode) {
    if (mode === 'T') return dateStr.slice(0, 4) + '-T' + Math.ceil(+dateStr.slice(5, 7) / 3);
    return dateStr.slice(0, 7);
  }
  function periodLabel(key) {
    if (key.indexOf('T') >= 0) return 'T' + key.slice(-1) + ' ' + key.slice(0, 4);
    return MOIS_FR[+key.slice(5, 7) - 1] + ' ' + key.slice(0, 4);
  }
  function periodDeadline(key) { // dernier jour du mois suivant la fin de période
    var y = +key.slice(0, 4);
    var endMonth = key.indexOf('T') >= 0 ? +key.slice(-1) * 3 : +key.slice(5, 7);
    return new Date(Date.UTC(y, endMonth + 1, 0)).toISOString().slice(0, 10);
  }
  function frDate(iso) { return iso.slice(8, 10) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4); }
  window.showUrssaf = function () {
    if (!hasSettings()) { window.showSettings(); return; }
    hideAll(); $('urssaf').classList.remove('hide');
    var s = urssafSettings();
    $('u_rate').value = s.rate; $('u_period').value = s.period;
    renderUrssaf();
  };
  function renderUrssaf() {
    var s = urssafSettings(), body = $('u_body');
    body.innerHTML = '<p class="muted" style="text-align:center">Chargement des factures…</p>';
    kw('account.move', 'search_read', [[['move_type', '=', 'out_invoice'], ['state', '=', 'posted']]],
      { fields: ['invoice_date', 'amount_total', 'payment_state', 'name'] })
      .then(function (invs) {
        var groups = {};
        invs.forEach(function (i) {
          if (!i.invoice_date) return;
          var k = periodKey(i.invoice_date, s.period);
          groups[k] = groups[k] || { ca: 0, paid: 0, n: 0 };
          groups[k].ca += i.amount_total; groups[k].n++;
          if (i.payment_state === 'paid' || i.payment_state === 'in_payment') groups[k].paid += i.amount_total;
        });
        var keys = Object.keys(groups).sort().reverse();
        if (!keys.length) { body.innerHTML = '<div class="card"><p class="muted">Aucune facture comptabilisée pour l\'instant.</p></div>'; return; }
        var today = new Date().toISOString().slice(0, 10);
        var currentK = periodKey(today, s.period);
        var html = '', history = '';
        keys.slice(0, 10).forEach(function (k) {
          var g = groups[k];
          var cot = Math.round(g.ca * s.rate) / 100;
          var dl = periodDeadline(k);
          if (k === currentK) {
            html += '<div class="card"><span class="badge">⏳ Période en cours</span>' +
              '<h3 style="margin:8px 0 4px">' + periodLabel(k) + '</h3>' +
              '<p style="margin:2px 0">' + euro(g.ca) + ' facturés (' + g.n + ' facture' + (g.n > 1 ? 's' : '') + ') — cotisations estimées : <b>' + euro(cot) + '</b></p>' +
              '<p class="muted" style="font-size:12.5px;margin:2px 0">À déclarer après la fin de la période, avant le ' + frDate(dl) + '.</p></div>';
          } else if (dl >= today) {
            html += '<div class="card" style="border-color:var(--accent)">' +
              '<span class="badge warn">📣 À déclarer avant le ' + frDate(dl) + '</span>' +
              '<h3 style="margin:8px 0 2px">CA de ' + periodLabel(k) + '</h3>' +
              '<div style="font-size:32px;font-weight:800;margin:4px 0">' + euro(g.ca) + '</div>' +
              '<p style="margin:2px 0 12px">Cotisations estimées (' + String(s.rate).replace('.', ',') + ' %) : <b>' + euro(cot) + '</b>' +
              (g.paid < g.ca - 0.005 ? '<br><span class="muted" style="font-size:12.5px">dont encaissé selon Odoo : ' + euro(g.paid) + '</span>' : '') + '</p>' +
              '<button class="btn-ghost" onclick="copyCA(' + Math.round(g.ca) + ')" style="margin-bottom:8px">📋 Copier le CA (' + Math.round(g.ca) + ' €)</button>' +
              '<a href="https://www.autoentrepreneur.urssaf.fr/" target="_blank" style="display:block"><button class="btn-primary">Déclarer sur urssaf.fr ↗</button></a></div>';
          } else {
            history += '<div class="line"><span class="r">' + euro(g.ca) + ' → <b>' + euro(cot) + '</b></span>' + periodLabel(k) + '<br><small class="muted">échéance passée (' + frDate(dl) + ')</small></div>';
          }
        });
        if (history) html += '<div class="card"><h3 style="margin-top:0">Périodes précédentes</h3>' + history + '</div>';
        body.innerHTML = html;
      })
      .catch(function (e) { body.innerHTML = '<div class="alert exist">❌ ' + esc(e.message) + '</div>'; });
  }
  window.copyCA = function (v) {
    var sv = String(v);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(sv).then(function () { toast('📋 Copié : ' + sv + ' € — colle-le dans le champ URSSAF'); },
        function () { prompt('Copie manuelle :', sv); });
    } else { prompt('Copie manuelle :', sv); }
  };

  // ---------- écrans ----------
  function hideAll() { ['settings', 'pick', 'months', 'detail', 'urssaf'].forEach(function (s) { $(s).classList.add('hide'); }); }
  window.showSettings = function () { hideAll(); fillSettings(); $('settings').classList.remove('hide'); };
  window.showMonths = function () { hideAll(); $('months').classList.remove('hide'); };
  window.reset = function () {
    STATE.months = []; STATE.sel = null;
    if (!hasSettings()) { window.showSettings(); return; }
    hideAll(); $('pick').classList.remove('hide'); $('file').value = ''; $('pick_msg').textContent = '';
    $('gs_url').value = localStorage.getItem('gs_url') || '';
  };

  function euro(x) { return x.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'; }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  // ---------- lecture (fichier OU lien Google Sheets) ----------
  function parseBuffer(u8) {
    var msg = $('pick_msg');
    var files;
    try { files = fflate.unzipSync(u8); }
    catch (e) { msg.innerHTML = '❌ Ce n\'est pas un fichier Excel (.xlsx) valide.\nSi c\'est un Google Sheets, colle plutôt son lien ci-dessus.'; return; }
    try { STATE.months = FactuCore.monthsFromXlsx(files); }
    catch (e) { msg.textContent = '❌ Lecture du planning impossible : ' + e.message; return; }
    if (!STATE.months.length) { msg.textContent = '⚠️ Aucune mission trouvée dans ce fichier.'; return; }
    msg.textContent = 'Analyse Odoo…';
    existingByMonth().then(function (ex) {
      STATE.months.forEach(function (m) { m.existing = ex[m.key] || []; });
      renderMonths();
    });
  }

  $('file').addEventListener('change', function (e) {
    var f = e.target.files[0]; if (!f) return;
    $('pick_msg').textContent = 'Lecture de ' + f.name + '…';
    var reader = new FileReader();
    reader.onerror = function () { $('pick_msg').textContent = '❌ Impossible de lire ce fichier. S\'il vient du Drive, télécharge-le d\'abord sur le téléphone (ou colle le lien Google Sheets ci-dessus).'; };
    reader.onload = function () { parseBuffer(new Uint8Array(reader.result)); };
    reader.readAsArrayBuffer(f);
  });

  function extractSheetId(s) {
    var m = s.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/) || s.match(/^([a-zA-Z0-9-_]{20,})$/);
    return m ? m[1] : null;
  }
  function b64ToU8(b64) {
    var bin = atob(b64), n = bin.length, u8 = new Uint8Array(n);
    for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }
  function httpGetBinary(url) {
    var Cap = window.Capacitor;
    if (Cap && Cap.Plugins && Cap.Plugins.CapacitorHttp) {
      return Cap.Plugins.CapacitorHttp.get({ url: url, responseType: 'arraybuffer' })
        .then(function (res) {
          if (res.status && res.status >= 400) throw new Error('HTTP ' + res.status);
          return b64ToU8(res.data);
        });
    }
    return fetch(url).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); }).then(function (b) { return new Uint8Array(b); });
  }
  window.loadFromUrl = function () {
    var raw = $('gs_url').value.trim(), msg = $('pick_msg');
    if (!raw) { msg.textContent = 'Colle d\'abord le lien de ton Google Sheets.'; return; }
    var id = extractSheetId(raw);
    if (!id) { msg.textContent = '❌ Lien Google Sheets non reconnu. Copie le lien depuis « Partager ».'; return; }
    msg.textContent = 'Chargement depuis Google Sheets…';
    httpGetBinary('https://docs.google.com/spreadsheets/d/' + id + '/export?format=xlsx')
      .then(function (u8) { localStorage.setItem('gs_url', raw); parseBuffer(u8); })
      .catch(function () { msg.innerHTML = '❌ Impossible de charger ce lien.\nVérifie qu\'il est partagé en lecture (« Tous les utilisateurs disposant du lien »).'; });
  };

  // ---------- statuts Odoo ----------
  function monthStatus(m) {
    var ex = m.existing || [];
    var posted = ex.filter(function (e) { return e.state === 'posted'; });
    var drafts = ex.filter(function (e) { return e.state === 'draft'; });
    // brouillon cible = celui qui porte le nom du mois, sinon le plus récent
    var target = null;
    drafts.forEach(function (d) { if (d.name === m.invoiceName) target = d; });
    if (!target && drafts.length) target = drafts.reduce(function (a, b) { return (b.id > a.id ? b : a); });
    return { posted: posted, drafts: drafts, draftTarget: target };
  }
  function statusBadges(m) {
    var st = monthStatus(m), b = '';
    st.posted.forEach(function (p) { b += p.sent ? '<span class="badge ok">📤 Envoyée</span>' : '<span class="badge ok">✅ Comptabilisée</span>'; });
    if (st.drafts.length) b += '<span class="badge warn">📝 Brouillon</span>';
    if (!m.existing || !m.existing.length) b += '<span class="badge">Pas sur Odoo</span>';
    return b;
  }

  function renderMonths() {
    var box = $('months_list'); box.innerHTML = '';
    STATE.months.forEach(function (m, i) {
      var d = document.createElement('div'); d.className = 'month'; d.onclick = function () { selectMonth(i); };
      var badges = statusBadges(m);
      if (m.anomalies.length) badges += '<span class="badge warn">⚠️ ' + m.anomalies.length + '</span>';
      d.innerHTML = '<div><b>' + m.label + '</b><br><small>' + m.missionsActive + ' prestation' + (m.missionsActive > 1 ? 's' : '') + '</small><div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:5px">' + badges + '</div></div><div class="amt">' + euro(m.total) + '</div>';
      box.appendChild(d);
    });
    showMonths();
  }

  function selectMonth(i) {
    STATE.sel = i; var m = STATE.months[i]; hideAll(); $('detail').classList.remove('hide');
    var st = monthStatus(m);
    var rows = '';
    m.prestationLines.forEach(function (l) { rows += '<div class="line"><span class="r">' + euro(l.quantity * l.price_unit) + '</span>' + esc(l.name) + '</div>'; });
    if (m.meal) rows += '<div class="line muted"><span class="r">' + euro(m.meal.amount) + '</span>' + esc(m.meal.name) + '</div>';

    var alerts = '';
    st.posted.forEach(function (p) {
      alerts += '<div class="alert ok">✅ Facture « ' + esc(p.name) + ' » <b>comptabilisée</b> — ' + euro(p.amount) + (p.sent ? ' · 📤 envoyée au client' : ' · pas encore envoyée au client') + '</div>';
    });
    if (st.draftTarget) {
      var d = st.draftTarget;
      var diff = Math.abs(d.amount - m.total) > 0.005;
      alerts += '<div class="alert warn">📝 Brouillon « ' + esc(d.name) + ' » déjà sur Odoo — ' + euro(d.amount) + ', ' + d.nlines + ' ligne' + (d.nlines > 1 ? 's' : '') +
        (diff ? '.<br><b>Le planning donne ' + euro(m.total) + '</b> → appuie sur « Mettre à jour » pour synchroniser.' : ' — identique au planning ✓') + '</div>';
      if (st.drafts.length > 1) alerts += '<div class="alert warn">⚠️ ' + st.drafts.length + ' brouillons existent pour ce mois — je mettrai à jour « ' + esc(d.name) + ' ». Supprime les autres dans Odoo.</div>';
    }
    if (m.anomalies.length) alerts += '<div class="alert warn"><b>À vérifier dans Odoo :</b><br>' + m.anomalies.map(function (a) { return '• Réf ' + esc(a.ref) + ' — ' + esc(a.msg); }).join('<br>') + '</div>';
    if (m.skipped.length) alerts += '<div class="alert warn">Indispo ignorées : ' + m.skipped.map(function (s) { return esc(s.venue); }).join(', ') + '</div>';

    // Boutons selon l'état : rien -> Créer ; brouillon -> Comptabiliser / Mettre à jour ; comptabilisée -> Envoyer
    var postedTarget = st.posted.length ? pickByName(st.posted, m.invoiceName) : null;
    if (postedTarget && !st.draftTarget && Math.abs(postedTarget.amount - m.total) > 0.005) {
      alerts += '<div class="alert warn">⚠️ Le planning donne ' + euro(m.total) + ' mais la facture comptabilisée fait ' + euro(postedTarget.amount) + '. Une facture comptabilisée n\'est plus modifiable — gère l\'écart dans Odoo (avoir ou facture complémentaire).</div>';
    }
    var btns;
    if (st.draftTarget) {
      btns = '<button class="btn-primary" id="postBtn">🧾 Comptabiliser la facture</button>' +
        '<div style="margin-top:8px"><button class="btn-ghost" id="updateBtn">🔄 Mettre à jour le brouillon depuis le planning</button></div>';
    } else if (postedTarget) {
      btns = postedTarget.sent
        ? '<div class="alert ok" style="text-align:center;margin:0">📤 Facture envoyée au client ✓</div>'
        : '<button class="btn-primary" id="sendBtn">📤 Envoyer par email au client</button>';
    } else {
      btns = '<button class="btn-primary" id="createBtn">✅ Créer le brouillon dans Odoo</button>';
    }

    $('detail_body').innerHTML =
      '<div class="card"><h2 style="margin-top:0;font-size:17px">' + m.label + '</h2>' +
      '<p class="muted" style="font-size:13px;margin-top:-6px">Facture du ' + m.invoiceDate + ' — Les Cuistots Migrateurs</p>' +
      alerts + rows +
      '<div class="total"><span>TOTAL (TVA 0 %)</span><span>' + euro(m.total) + '</span></div>' +
      '<div id="result" style="margin:10px 0"></div>' + btns + '</div>';
    var b;
    if ((b = $('createBtn'))) b.onclick = doCreate;
    if ((b = $('updateBtn'))) b.onclick = doUpdate;
    if ((b = $('postBtn'))) b.onclick = doPost;
    if ((b = $('sendBtn'))) b.onclick = doSend;
  }

  function refreshDetail(okHtml) { selectMonth(STATE.sel); if (okHtml) $('result').innerHTML = okHtml; }
  function opError(btnId, label) {
    return function (e) {
      var out = $('result'), btn = $(btnId);
      if (out) out.innerHTML = '<div class="alert exist">❌ ' + esc(e.message) + '</div>';
      if (btn) { btn.disabled = false; btn.innerHTML = label; }
    };
  }

  function doCreate() {
    var m = STATE.months[STATE.sel], btn = $('createBtn');
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Création…'; $('result').innerHTML = '';
    createDraft(m).then(function (r) {
      m.existing = (m.existing || []).concat([{ id: r.id, name: (r.name && r.name !== '/') ? r.name : m.invoiceName, state: 'draft', amount: r.amount_total, nlines: m.prestationLines.length + (m.meal ? 1 : 0), sent: false }]);
      refreshDetail('<div class="alert ok">✅ Brouillon créé (' + euro(r.amount_total) + ') — <a href="' + r.url + '" target="_blank">ouvrir dans Odoo</a></div>');
    }).catch(opError('createBtn', '✅ Créer le brouillon dans Odoo'));
  }

  function doUpdate() {
    var m = STATE.months[STATE.sel], st = monthStatus(m);
    if (!st.draftTarget) return;
    var btn = $('updateBtn');
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Mise à jour…'; $('result').innerHTML = '';
    updateDraft(m, st.draftTarget.id).then(function (r) {
      st.draftTarget.amount = r.amount_total; st.draftTarget.nlines = r.nlines || st.draftTarget.nlines;
      if (r.name && r.name !== '/') st.draftTarget.name = r.name;
      refreshDetail('<div class="alert ok">✅ Brouillon mis à jour (' + euro(r.amount_total) + ') — <a href="' + r.url + '" target="_blank">ouvrir dans Odoo</a></div>');
    }).catch(opError('updateBtn', '🔄 Mettre à jour le brouillon depuis le planning'));
  }

  function doPost() {
    var m = STATE.months[STATE.sel], st = monthStatus(m), d = st.draftTarget;
    if (!d) return;
    if (!confirm('Comptabiliser la facture « ' + m.invoiceName + ' » (' + euro(d.amount) + ') ?\n\nElle ne sera plus modifiable ensuite.')) return;
    var btn = $('postBtn');
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Comptabilisation…'; $('result').innerHTML = '';
    postInvoice(d.id)
      .then(function () { return kw('account.move', 'read', [[d.id], ['name', 'state', 'amount_total']]); })
      .then(function (r) {
        d.state = 'posted'; d.amount = r[0].amount_total;
        if (r[0].name && r[0].name !== '/') d.name = r[0].name;
        refreshDetail('<div class="alert ok">✅ Facture comptabilisée. Tu peux maintenant l\'envoyer au client.</div>');
      })
      .catch(opError('postBtn', '🧾 Comptabiliser la facture'));
  }

  function doSend() {
    var m = STATE.months[STATE.sel], st = monthStatus(m);
    var p = st.posted.length ? pickByName(st.posted, m.invoiceName) : null;
    if (!p) return;
    var btn = $('sendBtn');
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Préparation…';
    getClientEmail().then(function (email) {
      if (!confirm('Envoyer la facture « ' + p.name + ' » (' + euro(p.amount) + ') par email à :\n\n' + email + ' ?')) {
        btn.disabled = false; btn.innerHTML = '📤 Envoyer par email au client'; return;
      }
      btn.innerHTML = '<span class="spin"></span>Envoi…'; $('result').innerHTML = '';
      sendInvoice(p.id).then(function () {
        p.sent = true;
        refreshDetail('<div class="alert ok">📤 Facture envoyée à ' + esc(email) + ' ✓</div>');
      }).catch(opError('sendBtn', '📤 Envoyer par email au client'));
    }).catch(opError('sendBtn', '📤 Envoyer par email au client'));
  }

  // ---------- démarrage ----------
  var CU = updaterPlugin();
  if (CU && CU.notifyAppReady) { try { CU.notifyAppReady(); } catch (e) {} }
  reset();
  checkUpdate(false);
})();
