/* Appli mobile — logique. Utilise window.fflate, window.FactuCore.
   Les appels réseau passent par fetch() ; dans l'APK, CapacitorHttp les route
   en natif → pas de blocage CORS, comme le serveur du PC. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };

  // Version du bundle web — les mises à jour OTA comparent ce numéro à version.json
  var APP_VERSION = '1.1.0';
  var UPDATE_BASE = 'https://raw.githubusercontent.com/swipestudio1m-cyber/facturation-cuistots-updates/main';

  var DEFAULTS = { url: '', db: '', login: '', key: '' };
  var STATE = { months: [], sel: null, uid: null };

  // ---------- réglages (stockés sur le téléphone) ----------
  function getSettings() {
    try { return JSON.parse(localStorage.getItem('odoo') || 'null') || DEFAULTS; } catch (e) { return DEFAULTS; }
  }
  function hasSettings() { var s = getSettings(); return s && s.url && s.db && s.login && s.key; }
  function fillSettings() {
    var s = getSettings();
    $('s_url').value = s.url || ''; $('s_db').value = s.db || ''; $('s_login').value = s.login || ''; $('s_key').value = s.key || '';
    $('app_ver').textContent = APP_VERSION;
  }
  window.saveSettings = function () {
    var s = { url: $('s_url').value.trim().replace(/\/+$/, ''), db: $('s_db').value.trim(), login: $('s_login').value.trim(), key: $('s_key').value.trim() };
    if (!s.url || !s.db || !s.login || !s.key) { $('s_msg').textContent = '⚠️ Remplis tous les champs.'; return; }
    localStorage.setItem('odoo', JSON.stringify(s)); STATE.uid = null;
    $('s_msg').textContent = '✅ Enregistré.'; setTimeout(reset, 500);
  };

  // ---------- Odoo ----------
  function rpc(service, method, args) {
    var s = getSettings();
    return fetch(s.url + '/jsonrpc', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', method: 'call', params: { service: service, method: method, args: args }, id: 1 }) })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j.error) throw new Error((j.error.data && j.error.data.message) || j.error.message || 'Erreur Odoo'); return j.result; });
  }
  function auth() {
    var s = getSettings();
    if (STATE.uid) return Promise.resolve(STATE.uid);
    return rpc('common', 'authenticate', [s.db, s.login, s.key, {}]).then(function (uid) {
      if (!uid) throw new Error('Connexion refusée (identifiant ou clé API incorrects).'); STATE.uid = uid; return uid;
    });
  }
  function kw(model, method, args, kwargs) {
    var s = getSettings();
    return auth().then(function (uid) { return rpc('object', 'execute_kw', [s.db, uid, s.key, model, method, args, kwargs || {}]); });
  }
  window.testOdoo = function () {
    $('s_msg').textContent = 'Test en cours…'; STATE.uid = null;
    auth().then(function () { return kw('res.users', 'read', [[STATE.uid], ['name']]); })
      .then(function (u) { $('s_msg').textContent = '✅ Connecté : ' + u[0].name; })
      .catch(function (e) { $('s_msg').textContent = '❌ ' + e.message; });
  };

  // Factures existantes par mois (id, état, envoyée ou non)
  function existingByMonth() {
    var domain = [[['partner_id', '=', FactuCore.CLIENT_ID], ['move_type', '=', 'out_invoice']]];
    var base = ['id', 'name', 'state', 'invoice_date', 'amount_total', 'invoice_line_ids'];
    function q(fields) { return kw('account.move', 'search_read', domain, { fields: fields }); }
    return q(base.concat(['is_move_sent'])).catch(function () { return q(base); })
      .then(function (invs) {
        var map = {};
        invs.forEach(function (i) {
          if (!i.invoice_date) return;
          var k = i.invoice_date.slice(0, 7);
          (map[k] = map[k] || []).push({
            id: i.id, name: (i.name && i.name !== '/') ? i.name : '(brouillon)',
            state: i.state, amount: i.amount_total, nlines: (i.invoice_line_ids || []).length,
            sent: !!i.is_move_sent,
          });
        });
        return map;
      }).catch(function () { return {}; });
  }

  function lineCommands(mo) {
    var cmds = mo.prestationLines.map(function (l) { return [0, 0, { product_id: l.product_id, name: l.name, quantity: l.quantity, price_unit: l.price_unit, tax_ids: [[6, 0, l.tax]], account_id: FactuCore.ACC_PREST }]; });
    if (mo.meal) cmds.push([0, 0, { product_id: mo.meal.product_id, name: mo.meal.name, quantity: mo.meal.quantity, price_unit: mo.meal.price_unit, tax_ids: [[6, 0, []]], account_id: FactuCore.ACC_MEAL }]);
    return cmds;
  }
  function createDraft(mo) {
    return kw('account.move', 'create', [{ move_type: 'out_invoice', partner_id: FactuCore.CLIENT_ID, invoice_date: mo.invoiceDate, invoice_payment_term_id: FactuCore.PAYMENT_TERM_ID, invoice_line_ids: lineCommands(mo) }])
      .then(function (id) {
        return kw('account.move', 'write', [[id], { name: mo.invoiceName }]).catch(function () {}).then(function () {
          return kw('account.move', 'read', [[id], ['name', 'amount_total']]).then(function (b) {
            return { id: id, name: b[0].name, amount_total: b[0].amount_total, url: getSettings().url + '/odoo/action-account.move/' + id };
          });
        });
      });
  }
  // Remplace toutes les lignes du brouillon existant par celles du planning
  function updateDraft(mo, draftId) {
    var cmds = [[5, 0, 0]].concat(lineCommands(mo));
    return kw('account.move', 'write', [[draftId], { invoice_date: mo.invoiceDate, invoice_line_ids: cmds }])
      .then(function () { return kw('account.move', 'read', [[draftId], ['name', 'amount_total', 'invoice_line_ids']]); })
      .then(function (b) {
        return { id: draftId, name: b[0].name, amount_total: b[0].amount_total, nlines: (b[0].invoice_line_ids || []).length, url: getSettings().url + '/odoo/action-account.move/' + draftId };
      });
  }

  // ---------- mises à jour automatiques (OTA) ----------
  function isNewer(a, b) {
    var pa = String(a).split('.'), pb = String(b).split('.');
    for (var i = 0; i < 3; i++) { var x = +pa[i] || 0, y = +pb[i] || 0; if (x > y) return true; if (x < y) return false; }
    return false;
  }
  function toast(txt) {
    var t = document.createElement('div');
    t.textContent = txt;
    t.style.cssText = 'position:fixed;left:14px;right:14px;bottom:18px;background:var(--panel2);border:1px solid var(--accent);color:var(--txt);padding:13px 16px;border-radius:12px;z-index:99;text-align:center;font-size:14px';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 6000);
    return t;
  }
  function updaterPlugin() {
    var C = window.Capacitor;
    return (C && C.Plugins && C.Plugins.CapacitorUpdater) || null;
  }
  function checkUpdate(manual) {
    var CU = updaterPlugin();
    if (!CU) { if (manual) $('s_msg').textContent = 'Mises à jour indisponibles (mode navigateur).'; return; }
    if (manual) $('s_msg').textContent = 'Recherche de mise à jour…';
    fetch(UPDATE_BASE + '/version.json?t=' + Date.now())
      .then(function (r) { return r.json(); })
      .then(function (info) {
        if (!info || !info.version || !isNewer(info.version, APP_VERSION)) {
          if (manual) $('s_msg').textContent = '✅ Application à jour (v' + APP_VERSION + ').';
          return;
        }
        toast('⬇️ Mise à jour v' + info.version + ' — installation…');
        if (manual) $('s_msg').textContent = '⬇️ Téléchargement de la v' + info.version + '…';
        return CU.download({ url: UPDATE_BASE + '/www.zip', version: info.version })
          .then(function (b) { return CU.set({ id: b.id }); });   // l'appli redémarre toute seule
      })
      .catch(function (e) { if (manual) $('s_msg').textContent = '❌ Vérification impossible (' + (e.message || 'réseau') + ').'; });
  }
  window.checkUpdateManual = function () { checkUpdate(true); };

  // ---------- écrans ----------
  function hideAll() { ['settings', 'pick', 'months', 'detail'].forEach(function (s) { $(s).classList.add('hide'); }); }
  window.showSettings = function () { hideAll(); fillSettings(); $('settings').classList.remove('hide'); };
  window.showMonths = function () { hideAll(); $('months').classList.remove('hide'); };
  window.reset = function () {
    STATE.months = []; STATE.sel = null;
    if (!hasSettings()) { window.showSettings(); return; }
    hideAll(); $('pick').classList.remove('hide'); $('file').value = ''; $('pick_msg').textContent = '';
    $('gs_url').value = localStorage.getItem('gs_url') || '';
  };

  function euro(x) { return x.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'; }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  // ---------- lecture (fichier OU lien Google Sheets) ----------
  function parseBuffer(u8) {
    var msg = $('pick_msg');
    var files;
    try { files = fflate.unzipSync(u8); }
    catch (e) { msg.innerHTML = '❌ Ce n\'est pas un fichier Excel (.xlsx) valide.\nSi c\'est un Google Sheets, colle plutôt son lien ci-dessus.'; return; }
    try { STATE.months = FactuCore.monthsFromXlsx(files); }
    catch (e) { msg.textContent = '❌ Lecture du planning impossible : ' + e.message; return; }
    if (!STATE.months.length) { msg.textContent = '⚠️ Aucune mission trouvée dans ce fichier.'; return; }
    msg.textContent = 'Analyse Odoo…';
    existingByMonth().then(function (ex) {
      STATE.months.forEach(function (m) { m.existing = ex[m.key] || []; });
      renderMonths();
    });
  }

  $('file').addEventListener('change', function (e) {
    var f = e.target.files[0]; if (!f) return;
    $('pick_msg').textContent = 'Lecture de ' + f.name + '…';
    var reader = new FileReader();
    reader.onerror = function () { $('pick_msg').textContent = '❌ Impossible de lire ce fichier. S\'il vient du Drive, télécharge-le d\'abord sur le téléphone (ou colle le lien Google Sheets ci-dessus).'; };
    reader.onload = function () { parseBuffer(new Uint8Array(reader.result)); };
    reader.readAsArrayBuffer(f);
  });

  function extractSheetId(s) {
    var m = s.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/) || s.match(/^([a-zA-Z0-9-_]{20,})$/);
    return m ? m[1] : null;
  }
  function b64ToU8(b64) {
    var bin = atob(b64), n = bin.length, u8 = new Uint8Array(n);
    for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }
  function httpGetBinary(url) {
    var Cap = window.Capacitor;
    if (Cap && Cap.Plugins && Cap.Plugins.CapacitorHttp) {
      return Cap.Plugins.CapacitorHttp.get({ url: url, responseType: 'arraybuffer' })
        .then(function (res) {
          if (res.status && res.status >= 400) throw new Error('HTTP ' + res.status);
          return b64ToU8(res.data);
        });
    }
    return fetch(url).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); }).then(function (b) { return new Uint8Array(b); });
  }
  window.loadFromUrl = function () {
    var raw = $('gs_url').value.trim(), msg = $('pick_msg');
    if (!raw) { msg.textContent = 'Colle d\'abord le lien de ton Google Sheets.'; return; }
    var id = extractSheetId(raw);
    if (!id) { msg.textContent = '❌ Lien Google Sheets non reconnu. Copie le lien depuis « Partager ».'; return; }
    msg.textContent = 'Chargement depuis Google Sheets…';
    httpGetBinary('https://docs.google.com/spreadsheets/d/' + id + '/export?format=xlsx')
      .then(function (u8) { localStorage.setItem('gs_url', raw); parseBuffer(u8); })
      .catch(function () { msg.innerHTML = '❌ Impossible de charger ce lien.\nVérifie qu\'il est partagé en lecture (« Tous les utilisateurs disposant du lien »).'; });
  };

  // ---------- statuts Odoo ----------
  function monthStatus(m) {
    var ex = m.existing || [];
    var posted = ex.filter(function (e) { return e.state === 'posted'; });
    var drafts = ex.filter(function (e) { return e.state === 'draft'; });
    // brouillon cible = celui qui porte le nom du mois, sinon le plus récent
    var target = null;
    drafts.forEach(function (d) { if (d.name === m.invoiceName) target = d; });
    if (!target && drafts.length) target = drafts.reduce(function (a, b) { return (b.id > a.id ? b : a); });
    return { posted: posted, drafts: drafts, draftTarget: target };
  }
  function statusBadges(m) {
    var st = monthStatus(m), b = '';
    st.posted.forEach(function (p) { b += p.sent ? '<span class="badge ok">📤 Envoyée</span>' : '<span class="badge ok">✅ Comptabilisée</span>'; });
    if (st.drafts.length) b += '<span class="badge warn">📝 Brouillon</span>';
    if (!m.existing || !m.existing.length) b += '<span class="badge">Pas sur Odoo</span>';
    return b;
  }

  function renderMonths() {
    var box = $('months_list'); box.innerHTML = '';
    STATE.months.forEach(function (m, i) {
      var d = document.createElement('div'); d.className = 'month'; d.onclick = function () { selectMonth(i); };
      var badges = statusBadges(m);
      if (m.anomalies.length) badges += '<span class="badge warn">⚠️ ' + m.anomalies.length + '</span>';
      d.innerHTML = '<div><b>' + m.label + '</b><br><small>' + m.missionsActive + ' prestation' + (m.missionsActive > 1 ? 's' : '') + '</small><div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:5px">' + badges + '</div></div><div class="amt">' + euro(m.total) + '</div>';
      box.appendChild(d);
    });
    showMonths();
  }

  function selectMonth(i) {
    STATE.sel = i; var m = STATE.months[i]; hideAll(); $('detail').classList.remove('hide');
    var st = monthStatus(m);
    var rows = '';
    m.prestationLines.forEach(function (l) { rows += '<div class="line"><span class="r">' + euro(l.quantity * l.price_unit) + '</span>' + esc(l.name) + '</div>'; });
    if (m.meal) rows += '<div class="line muted"><span class="r">' + euro(m.meal.amount) + '</span>' + esc(m.meal.name) + '</div>';

    var alerts = '';
    st.posted.forEach(function (p) {
      alerts += '<div class="alert ok">✅ Facture « ' + esc(p.name) + ' » <b>comptabilisée</b> — ' + euro(p.amount) + (p.sent ? ' · 📤 envoyée au client' : ' · pas encore envoyée au client') + '</div>';
    });
    if (st.draftTarget) {
      var d = st.draftTarget;
      var diff = Math.abs(d.amount - m.total) > 0.005;
      alerts += '<div class="alert warn">📝 Brouillon « ' + esc(d.name) + ' » déjà sur Odoo — ' + euro(d.amount) + ', ' + d.nlines + ' ligne' + (d.nlines > 1 ? 's' : '') +
        (diff ? '.<br><b>Le planning donne ' + euro(m.total) + '</b> → appuie sur « Mettre à jour » pour synchroniser.' : ' — identique au planning ✓') + '</div>';
      if (st.drafts.length > 1) alerts += '<div class="alert warn">⚠️ ' + st.drafts.length + ' brouillons existent pour ce mois — je mettrai à jour « ' + esc(d.name) + ' ». Supprime les autres dans Odoo.</div>';
    }
    if (m.anomalies.length) alerts += '<div class="alert warn"><b>À vérifier dans Odoo :</b><br>' + m.anomalies.map(function (a) { return '• Réf ' + esc(a.ref) + ' — ' + esc(a.msg); }).join('<br>') + '</div>';
    if (m.skipped.length) alerts += '<div class="alert warn">Indispo ignorées : ' + m.skipped.map(function (s) { return esc(s.venue); }).join(', ') + '</div>';

    var btnLabel = st.draftTarget ? '🔄 Mettre à jour le brouillon' : (st.posted.length ? '➕ Créer un nouveau brouillon' : '✅ Créer le brouillon dans Odoo');

    $('detail_body').innerHTML =
      '<div class="card"><h2 style="margin-top:0;font-size:17px">' + m.label + '</h2>' +
      '<p class="muted" style="font-size:13px;margin-top:-6px">Facture du ' + m.invoiceDate + ' — Les Cuistots Migrateurs</p>' +
      alerts + rows +
      '<div class="total"><span>TOTAL (TVA 0 %)</span><span>' + euro(m.total) + '</span></div>' +
      '<div id="result" style="margin:10px 0"></div>' +
      '<button class="btn-primary" id="createBtn">' + btnLabel + '</button></div>';
    $('createBtn').onclick = doAction;
  }

  function doAction() {
    var m = STATE.months[STATE.sel], btn = $('createBtn'), out = $('result');
    var st = monthStatus(m);
    var updating = !!st.draftTarget;
    if (!updating && st.posted.length && !confirm('Une facture comptabilisée existe déjà pour ' + m.label + '.\nCréer quand même un NOUVEAU brouillon (risque de doublon) ?')) return;
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>' + (updating ? 'Mise à jour…' : 'Création…'); out.innerHTML = '';
    var op = updating ? updateDraft(m, st.draftTarget.id) : createDraft(m);
    op.then(function (r) {
      out.innerHTML = '<div class="alert ok">✅ Brouillon ' + (updating ? 'mis à jour' : 'créé') + ' (' + euro(r.amount_total) + ') — <a href="' + r.url + '" target="_blank">ouvrir dans Odoo</a></div>';
      btn.innerHTML = updating ? '✔ Mis à jour' : '✔ Créé';
      if (updating) {
        st.draftTarget.amount = r.amount_total; st.draftTarget.nlines = r.nlines || st.draftTarget.nlines;
        if (r.name && r.name !== '/') st.draftTarget.name = r.name;
      } else {
        m.existing = (m.existing || []).concat([{ id: r.id, name: r.name, state: 'draft', amount: r.amount_total, nlines: m.prestationLines.length + (m.meal ? 1 : 0), sent: false }]);
      }
    }).catch(function (e) {
      out.innerHTML = '<div class="alert exist">❌ ' + esc(e.message) + '</div>';
      btn.disabled = false; btn.innerHTML = updating ? '🔄 Mettre à jour le brouillon' : '✅ Créer le brouillon dans Odoo';
    });
  }

  // ---------- démarrage ----------
  var CU = updaterPlugin();
  if (CU && CU.notifyAppReady) { try { CU.notifyAppReady(); } catch (e) {} }
  reset();
  checkUpdate(false);
})();
