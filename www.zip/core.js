// Cœur de calcul (identique à la version PC, validé au centime).
// S'attache à window.FactuCore pour être utilisé dans le téléphone sans bundler.
(function (global) {
  'use strict';
  var TXT = new TextDecoder('utf-8');
  var t = function (u8) { return u8 ? TXT.decode(u8) : ''; };

  var RATE_DAY = 24, RATE_NIGHT = 36, MEAL_UNIT = 4.5;
  var CLIENT_ID = 9, PAYMENT_TERM_ID = 1;
  var PROD_PREST = 1, PROD_REPAS = 2, TAX_EXEMPT = 42, ACC_PREST = 243, ACC_MEAL = 676;
  var MOIS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
  var cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
  var round2 = function (x) { return Math.round(x * 100) / 100; };
  var eur = function (x) { return x.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'; };

  function decodeXml(s) {
    return s.replace(/&#x([0-9a-fA-F]+);/g, function (_, h) { return String.fromCharCode(parseInt(h, 16)); })
      .replace(/&#(\d+);/g, function (_, d) { return String.fromCharCode(+d); })
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  }
  function sharedStrings(files) {
    var xml = t(files['xl/sharedStrings.xml']), out = [], re = /<si>([\s\S]*?)<\/si>/g, m;
    while ((m = re.exec(xml))) {
      var parts = m[1].match(/<t[^>]*>([\s\S]*?)<\/t>/g) || [];
      out.push(parts.map(function (p) { return decodeXml(p.replace(/<t[^>]*>/, '').replace(/<\/t>/, '')); }).join(''));
    }
    return out;
  }
  function firstSheetXml(files) {
    var wb = t(files['xl/workbook.xml']), rels = t(files['xl/_rels/workbook.xml.rels']);
    var sheet = wb.match(/<sheet\b[^>]*\/>/);
    if (sheet) {
      var rid = (sheet[0].match(/r:id="([^"]+)"/) || [])[1];
      if (rid) {
        var rel = rels.match(new RegExp('<Relationship[^>]*Id="' + rid + '"[^>]*>'));
        var target = rel && (rel[0].match(/Target="([^"]+)"/) || [])[1];
        if (target) { target = target.charAt(0) === '/' ? target.slice(1) : 'xl/' + target; if (files[target]) return t(files[target]); }
      }
    }
    var keys = Object.keys(files).filter(function (k) { return /^xl\/worksheets\/sheet\d+\.xml$/.test(k); }).sort();
    if (!keys.length) throw new Error('Aucune feuille dans le fichier Excel');
    return t(files[keys[0]]);
  }
  function parseSheet(xml, strings) {
    var rows = [], rowRe = /<row\b[^>]*\br="(\d+)"[^>]*>([\s\S]*?)<\/row>/g, rm;
    while ((rm = rowRe.exec(xml))) {
      var row = { __r: +rm[1] }, cellRe = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, cm;
      while ((cm = cellRe.exec(rm[2]))) {
        var attrs = cm[1], inner = cm[2] || '';
        var col = (attrs.match(/\br="([A-Z]+)\d+"/) || [])[1];
        if (!col) continue;
        var ty = (attrs.match(/\bt="([^"]+)"/) || [])[1], val, v;
        if (ty === 's') { v = inner.match(/<v>([\s\S]*?)<\/v>/); val = v ? strings[+v[1]] : ''; }
        else if (ty === 'inlineStr') { var ts = inner.match(/<t[^>]*>([\s\S]*?)<\/t>/g) || []; val = ts.map(function (x) { return decodeXml(x.replace(/<t[^>]*>/, '').replace(/<\/t>/, '')); }).join(''); }
        else if (ty === 'str') { v = inner.match(/<v>([\s\S]*?)<\/v>/); val = v ? decodeXml(v[1]) : ''; }
        else { v = inner.match(/<v>([\s\S]*?)<\/v>/); val = v ? Number(v[1]) : undefined; }
        if (val !== undefined && val !== '') row[col] = val;
      }
      rows.push(row);
    }
    return rows;
  }
  function excelDate(serial) {
    var days = Math.round(serial), dt = new Date(Date.UTC(1970, 0, 1) + (days - 25569) * 86400000);
    var dd = String(dt.getUTCDate()).padStart(2, '0'), mm = String(dt.getUTCMonth() + 1).padStart(2, '0'), y = dt.getUTCFullYear();
    return { ddmmyyyy: dd + '/' + mm + '/' + y, monthKey: y + '-' + mm, year: y, month: dt.getUTCMonth() + 1 };
  }
  function parseHM(v) {
    if (v === undefined || v === null || v === '') return { dec: 0, text: '' };
    var h = 0, m = 0;
    if (typeof v === 'number') { h = Math.floor(v); m = Math.round((v - h) * 60); }
    else { var s = String(v).trim(), mt = s.match(/(\d+)\s*h\s*(\d*)/i); if (mt) { h = +mt[1]; m = mt[2] ? +mt[2] : 0; } else { var n = Number(s.replace(',', '.')); if (!isNaN(n)) { h = Math.floor(n); m = Math.round((n - h) * 60); } } }
    var text = h > 0 || m === 0 ? h + ' heure' + (h > 1 ? 's' : '') : '';
    if (m) text += (text ? ' ' : '') + m + ' minutes';
    return { dec: round2(h + m / 60), text: text };
  }
  function splitC(c) {
    var lines = String(c == null ? '' : c).split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
    return { venue: lines[0] || '', address: lines[1] || '' };
  }
  function lastDayIso(y, m) { return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); }
  function missionLines(mi) {
    var head = 'Prestation horaire MH du ' + mi.date.ddmmyyyy + ' — Réf. ' + mi.ref + ' — ' + mi.venue, out = [];
    if (mi.night.dec > 0) {
      out.push({ product_id: PROD_PREST, price_unit: RATE_DAY, quantity: mi.day.dec, tax: [TAX_EXEMPT], name: head + '\n' + mi.address + ' — Heures de jour de ' + mi.start + ' à 0h00 — ' + mi.day.text });
      out.push({ product_id: PROD_PREST, price_unit: RATE_NIGHT, quantity: mi.night.dec, tax: [TAX_EXEMPT], name: head + '\n' + mi.address + ' — Heures de nuit de 00h00 à ' + mi.end + ' — ' + mi.night.text });
    } else {
      out.push({ product_id: PROD_PREST, price_unit: RATE_DAY, quantity: mi.day.dec, tax: [TAX_EXEMPT], name: head + '\n' + mi.address + ' — ' + mi.start + ' à ' + mi.end + ' — ' + mi.day.text });
    }
    return out;
  }
  function buildMonths(rows) {
    var map = new Map(), i;
    for (i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (typeof r.A !== 'number') continue;
      if (r.B === undefined) continue;
      var date = excelDate(r.A), c = splitC(r.C), day = parseHM(r.K), night = parseHM(r.L);
      var dispRaw = String(r.J == null ? '' : r.J).trim(), skipped = dispRaw.toLowerCase().indexOf('indispo') === 0;
      var start = r.G != null ? String(r.G).trim() : '', end = r.H != null ? String(r.H).trim() : '';
      var total = Number(r.N) || 0, expected = round2(day.dec * RATE_DAY + night.dec * RATE_NIGHT);
      var mi = { ref: String(Math.round(Number(r.B))), date: date, venue: c.venue, address: c.address, start: start, end: end, day: day, night: night, total: total, expected: expected, skipped: skipped, disp: dispRaw, anomalies: [] };
      if (!skipped) {
        if (!start) mi.anomalies.push('heure de début absente du planning');
        if (Math.abs(expected - total) > 0.01) mi.anomalies.push('total planning ' + eur(total) + ' ≠ ' + eur(expected) + ' calculé (heures × tarif) — à vérifier');
      }
      if (!map.has(date.monthKey)) map.set(date.monthKey, { key: date.monthKey, year: date.year, month: date.month, missions: [] });
      map.get(date.monthKey).missions.push(mi);
    }
    var out = [], groups = Array.from(map.values()).sort(function (a, b) { return a.key < b.key ? -1 : 1; });
    for (i = 0; i < groups.length; i++) {
      var g = groups[i], active = g.missions.filter(function (m) { return !m.skipped; });
      var lines = []; active.forEach(function (m) { lines = lines.concat(missionLines(m)); });
      var nameLower = MOIS[g.month - 1];
      var meal = lines.length ? { product_id: PROD_REPAS, name: 'Frais de repas non soumis — Prestations ' + nameLower + ' ' + g.year, quantity: lines.length, price_unit: MEAL_UNIT, tax: [], amount: round2(lines.length * MEAL_UNIT) } : null;
      var prestTotal = round2(lines.reduce(function (s, l) { return s + l.quantity * l.price_unit; }, 0));
      out.push({
        key: g.key, year: g.year, month: g.month, label: cap(nameLower) + ' ' + g.year, invoiceName: cap(nameLower) + ' ' + g.year,
        invoiceDate: lastDayIso(g.year, g.month), prestationLines: lines, meal: meal, prestTotal: prestTotal, total: round2(prestTotal + (meal ? meal.amount : 0)),
        missionsActive: active.length,
        skipped: g.missions.filter(function (m) { return m.skipped; }).map(function (m) { return { ref: m.ref, venue: m.venue, reason: m.disp }; }),
        anomalies: active.reduce(function (acc, m) { m.anomalies.forEach(function (a) { acc.push({ ref: m.ref, venue: m.venue, msg: a }); }); return acc; }, [])
      });
    }
    return out;
  }
  function monthsFromXlsx(files) { return buildMonths(parseSheet(firstSheetXml(files), sharedStrings(files))); }

  global.FactuCore = {
    monthsFromXlsx: monthsFromXlsx, eur: eur,
    CLIENT_ID: CLIENT_ID, PAYMENT_TERM_ID: PAYMENT_TERM_ID, ACC_PREST: ACC_PREST, ACC_MEAL: ACC_MEAL
  };
})(window);
